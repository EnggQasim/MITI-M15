;(function($, window, undefined) {

	"use strict";
 		jQuery('.statistic-counter').counterUp({
			delay: 10,
			time: 2000
		});
})(jQuery, window);
